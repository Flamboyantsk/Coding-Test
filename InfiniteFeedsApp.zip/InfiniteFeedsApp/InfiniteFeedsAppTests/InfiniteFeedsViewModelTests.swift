//
//  InfiniteFeedsViewModelTests.swift
//  InfiniteFeedsAppTests
//
//  Created by Farhan on 11/08/21.
//

import XCTest
@testable import InfiniteFeedsApp

class APIClientMock: DataProvider {
    var numberOfCalls = 0
    var errorMessage: DataResponseError?
    var successResponse: String?
    var expectedParam: [String : String]?

    func fetchRemote<Model>(_ val: Model.Type, param: [String : String]?, completion: @escaping (Result<Model, DataResponseError>) -> Void) where Model : Decodable, Model : Encodable {
        numberOfCalls += 1
        expectedParam = param
        
        if let errorMessage = self.errorMessage {
            completion(Result.failure(errorMessage))
            return
        } else if let successResponse = self.successResponse,
                  let data = successResponse.data(using: .utf8){
            do {
                let decodedResponse = try JSONDecoder().decode(Model.self, from: data)
                completion(Result.success(decodedResponse))
            } catch {
                completion(Result.failure(DataResponseError.decoding))
            }
        }
    }
}

class InfiniteFeedsViewModelTests: XCTestCase {

    private enum Constant {
        static let timeout: TimeInterval = 2
    }
    
    private var viewModel: InfiniteFeedsViewModel!
    private var apiClient: APIClientMock!
    
    override func setUp() {
        apiClient = APIClientMock()
        viewModel = InfiniteFeedsViewModel(apiClient: apiClient)
        super.setUp()
    }
    
    override func tearDown() {
        viewModel = nil
        super.tearDown()
    }
    
    func test_init_withDefaultValues_returnsCountZero() {
        XCTAssertEqual(viewModel.numberOfItems, 0)
        XCTAssertNil(viewModel.feedItemAt(index: 0))
    }
    
    func test_loadNextFeedIfAvailable_callingMultipleTimes_callsApiOnlyOnce() {
        viewModel.loadNextFeedIfAvailable()
        viewModel.loadNextFeedIfAvailable()
        XCTAssertEqual(apiClient.numberOfCalls, 1)
    }
    
    func test_loadNextFeedIfAvailable_returnLoadingIndicatorTrue() {
        let expectation = self.expectation(description: "waiting")

        viewModel.showLoadingIndicator = { show in
            XCTAssertTrue(show)
            expectation.fulfill()
        }
        viewModel.loadNextFeedIfAvailable()
        waitForExpectations(timeout: Constant.timeout, handler: nil)
    }
    
    func test_loadNextFeedIfAvailable_withNetworkIssue_callsAlertCallback() {
        let expectation = self.expectation(description: "waiting")
        apiClient.errorMessage = DataResponseError.network
        
        viewModel.showAlertClosure = { [weak self] in
            XCTAssertEqual(self?.viewModel.alertMessage, "An error occurred due to networks issue")
            expectation.fulfill()
        }
        viewModel.loadNextFeedIfAvailable()
        waitForExpectations(timeout: Constant.timeout, handler: nil)
    }
    
    func test_loadNextFeedIfAvailable_withData_callsReloadCallback() {
        let expectation = self.expectation(description: "waiting")
        apiClient.successResponse = self.getStubbedResponse()
        
        viewModel.reloadTableViewClosure = { [weak self] in
            XCTAssertEqual(self?.viewModel.numberOfItems, 4)
            expectation.fulfill()
        }
        viewModel.loadNextFeedIfAvailable()
        waitForExpectations(timeout: Constant.timeout, handler: nil)
    }
    
    func test_loadNextFeedIfAvailable_withPagination_callsReloadCallback() {
        let expectation = self.expectation(description: "waiting")
        apiClient.successResponse = self.getStubbedResponse()
        
        var isLoadedFirstTime = false
 
        viewModel.showLoadingIndicator = { [weak self] show in
            guard !show else { return }
            
            if !isLoadedFirstTime {
                XCTAssertEqual(self?.viewModel.numberOfItems, 4)
                isLoadedFirstTime = true
                self?.viewModel.loadNextFeedIfAvailable()
            } else {
                XCTAssertEqual(self?.viewModel.numberOfItems, 8)
                XCTAssertEqual(self?.apiClient.expectedParam, ["after": "t3_p2cmu4"])
                expectation.fulfill()
            }
        }
        viewModel.loadNextFeedIfAvailable()
        waitForExpectations(timeout: Constant.timeout, handler: nil)
    }
    
    func getStubbedResponse() -> String {
        guard let pathString = Bundle(for: type(of: self)).path(forResource: "UnitTestData", ofType: "json") else {
            fatalError("UnitTestData.json not found")
        }
        
        guard let jsonString = try? String(contentsOfFile: pathString, encoding: .utf8) else {
            fatalError("Unable to convert UnitTestData.json to String")
        }
        
        return jsonString
    }
}
