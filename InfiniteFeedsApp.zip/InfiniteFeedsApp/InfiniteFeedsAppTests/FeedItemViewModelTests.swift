//
//  FeedItemViewModelTests.swift
//  InfiniteFeedsAppTests
//
//  Created by Farhan on 12/08/21.
//

import XCTest
@testable import InfiniteFeedsApp


class FeedItemViewModelTests: XCTestCase {
    
    private var viewModel: FeedItemViewModel!
    
    func test_init_withNilValues_returnsNil() {
        let viewModel = FeedItemViewModel(feedItem: self.feedItem())
        
        XCTAssertNil(viewModel.imageUrl)
        XCTAssertNil(viewModel.title)
        XCTAssertEqual(viewModel.commentNumber, "Comments: 0")
        XCTAssertEqual(viewModel.score, "Score: 0")
        let imageSize = viewModel.imageSizeFor(viewWidth: 100)
        XCTAssertEqual(imageSize.width, 100)
        XCTAssertEqual(imageSize.height, 50)
    }
    
    func test_imageUrl_withValues_returnsValue() {
        let expectedUrl = "http://expectedUrl.com"
        let viewModel = FeedItemViewModel(feedItem: self.feedItem(imageUrl: expectedUrl))
        XCTAssertEqual(viewModel.imageUrl, expectedUrl)
    }
    
    func test_title_withValues_returnsValue() {
        let expectedTitle = "Expected Title"
        let viewModel = FeedItemViewModel(feedItem: self.feedItem(title: expectedTitle))
        XCTAssertEqual(viewModel.title, expectedTitle)
    }
    
    func test_commentNumber_withValues_returnsValue() {
        let expectedCommentNumber = 5
        let viewModel = FeedItemViewModel(feedItem: self.feedItem(commentNumber: expectedCommentNumber))
        XCTAssertEqual(viewModel.commentNumber, "Comments: \(expectedCommentNumber)")
    }
    
    func test_score_withValues_returnsValue() {
        let expectedScore = 5
        let viewModel = FeedItemViewModel(feedItem: self.feedItem(score: expectedScore))
        XCTAssertEqual(viewModel.score, "Score: \(expectedScore)")
    }
    
    func test_imageSizeFor_withValues_returnsValue() {
        let viewWidth: CGFloat = 300
        let imageWidth = 200
        let imageHeight = 100

        let viewModel = FeedItemViewModel(feedItem: self.feedItem(imageWidth: imageWidth,
                                                                  imageHeight: imageHeight))
        let imageSize = viewModel.imageSizeFor(viewWidth: viewWidth)
        
        let diff = viewWidth / CGFloat(imageWidth)

        XCTAssertEqual(imageSize.width, CGFloat(imageWidth) * diff)
        XCTAssertEqual(imageSize.height, CGFloat(imageHeight) * diff)
    }
    
    private func feedItem(title: String? = nil,
                          imageUrl: String? = nil,
                          imageWidth: Int? = nil,
                          imageHeight: Int? = nil,
                          commentNumber: Int? = nil,
                          score: Int? = nil) -> FeedItem {
        let data = FeedItem.Data(imageUrl: imageUrl,
                                 imageWidth: imageWidth,
                                 imageHeight: imageHeight,
                                 title: title,
                                 commentNumber: commentNumber,
                                 score: score)
        return FeedItem(data: data)
    }
}
