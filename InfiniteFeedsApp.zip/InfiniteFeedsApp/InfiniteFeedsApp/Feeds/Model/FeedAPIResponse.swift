//
//  FeedAPIResponse.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

class FeedAPIResponse: Codable {
    let data: Data
    
    struct Data: Codable {
        let feedItems: [FeedItem]
        let after: String?

        enum CodingKeys: String, CodingKey {
            case feedItems = "children"
            case after
        }
    }
}
