//
//  NetworkConfig.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

enum NetworkConfig {
    static let apiBaseUrl = "http://www.reddit.com/.json"
}
