//
//  FeedItem.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

struct FeedItem: Codable {
    let data: Data
    
    struct Data: Codable {
        let imageUrl: String?
        let imageWidth: Int?
        let imageHeight: Int?
        let title: String?
        let commentNumber: Int?
        let score: Int?

        enum CodingKeys: String, CodingKey {
            case imageUrl = "thumbnail"
            case title
            case commentNumber = "num_comments"
            case score
            case imageWidth = "thumbnail_width"
            case imageHeight = "thumbnail_height"
        }
    }
}
