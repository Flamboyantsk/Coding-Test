//
//  FeedsAPIClient.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import Foundation

enum DataResponseError: Error {
    case network
    case decoding
    
    var reason: String {
        switch self {
        case .network:
            return "An error occurred due to networks issue"
        case .decoding:
            return "An error occurred while decoding data"
        }
    }
}

extension HTTPURLResponse {
    var hasSuccessStatusCode: Bool {
        return 200...299 ~= statusCode
    }
}

enum Result<T, U: Error> {
    case success(T)
    case failure(U)
}

protocol DataProvider {
    func fetchRemote<Model: Codable>(_ val: Model.Type, param: [String: String]?, completion: @escaping (Result<Model, DataResponseError>) -> Void)
}

class FeedsAPIClient: DataProvider {
    let session: URLSession
    let baseUrlString: String

    init(session: URLSession = URLSession.shared, baseUrlString: String = NetworkConfig.apiBaseUrl) {
        self.session = session
        self.baseUrlString = baseUrlString
    }
    
    func fetchRemote<Model: Codable>(_ val: Model.Type,
                                     param: [String: String]?,
                                     completion: @escaping (Result<Model, DataResponseError>) -> Void) {
        var components = URLComponents(string: baseUrlString)!
        components.queryItems = param?.map { key, value in
            URLQueryItem(name: key, value: value)
        }
        components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        let urlRequest = URLRequest(url: components.url!)
        session.dataTask(with: urlRequest, completionHandler: { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse,
                httpResponse.hasSuccessStatusCode,
                let data = data
            else {
                completion(Result.failure(DataResponseError.network))
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(Model.self, from: data)
                completion(Result.success(decodedResponse))
            } catch {
                print(error)
                completion(Result.failure(DataResponseError.decoding))
            }
        }).resume()
    }
}
