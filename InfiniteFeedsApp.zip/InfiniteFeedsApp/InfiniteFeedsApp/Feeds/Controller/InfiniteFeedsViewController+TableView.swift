//
//  InfiniteFeedsViewController+TableView.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

extension InfiniteFeedsViewController: UITableViewDataSource, UITableViewDataSourcePrefetching {
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        guard indexPaths.last?.row == (self.viewModel.numberOfItems - 1) else { return }
        
        self.viewModel.loadNextFeedIfAvailable()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.numberOfItems
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: FeedsTableViewCell.id, for: indexPath) as! FeedsTableViewCell
        
        cell.viewModel = viewModel.feedItemAt(index: indexPath.row)
        
        return cell
    }
}

