//
//  InfiniteFeedsViewController.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

class InfiniteFeedsViewController: UIViewController {
    var viewModel = InfiniteFeedsViewModel()
    
    let activityIndicator: UIActivityIndicatorView = {
        UIActivityIndicatorView(style: .medium)
    }()

    private lazy var tableView : UITableView = {
        var tableView = UITableView()
        tableView.dataSource = self
        tableView.prefetchDataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableView.automaticDimension
        tableView.backgroundColor = .clear
        
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 242/255, green: 242/255, blue: 242/255, alpha: 1)
        
        self.view.addSubviewWithSafeArea(view: tableView, edges: .zero)
        tableView.tableFooterView = activityIndicator
        tableView.register(FeedsTableViewCell.self, forCellReuseIdentifier: FeedsTableViewCell.id)
        self.initViewModel()
        
        viewModel.loadNextFeedIfAvailable()
    }
    
    private func initViewModel() {
        viewModel.reloadTableViewClosure = {
            DispatchQueue.main.async { [weak self] in
                self?.tableView.reloadData()
            }
        }
        
        viewModel.showLoadingIndicator = { [weak self] isLoading in
            DispatchQueue.main.async {
                if isLoading {
                    self?.activityIndicator.startAnimating()
                } else {
                    self?.activityIndicator.stopAnimating()
                }
            }
        }
        
        viewModel.showAlertClosure = { [weak self] in
            DispatchQueue.main.async {
                if let message = self?.viewModel.alertMessage {
                    self?.showAlert(message)
                }
            }
        }
    }
    
    private func showAlert(_ message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
