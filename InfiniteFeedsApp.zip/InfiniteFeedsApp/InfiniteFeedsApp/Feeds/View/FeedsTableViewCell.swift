//
//  FeedsTableViewCell.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

class FeedsTableViewCell: UITableViewCell {
    static let id = "FeedsTableViewCell"
    
    let stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.backgroundColor = .white
        stackView.spacing = 12
        stackView.clipsToBounds = true
        return stackView
    }()
    
    let titleLabel = UILabel()
    let thumbnailImageView = UIImageView()
    let scoreLabel = UILabel()
    let commentsLabel = UILabel()
    var imageViewWidthConstraint: NSLayoutConstraint?
    var imageViewHeightConstraint: NSLayoutConstraint?

    var viewModel: FeedItemViewModel? {
        didSet {
            titleLabel.text = viewModel?.title
            scoreLabel.text = viewModel?.score
            commentsLabel.text = viewModel?.commentNumber
            if let imageUrl = viewModel?.imageUrl {
                thumbnailImageView.load(urlString: imageUrl, placeholder: UIImage(named: "placeholder"))
            }
            if let imageSize = viewModel?.imageSizeFor(viewWidth: thumbnailImageView.bounds.width) {
                self.imageViewHeightConstraint?.constant = imageSize.height
                self.imageViewWidthConstraint?.constant = imageSize.width
            }
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setUpViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUpViews() {
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        
        self.contentView.addSubview(view: stackView, edges: UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16))
        
        let titleContainer = UIView()
        titleContainer.addSubview(view: titleLabel, edges: UIEdgeInsets(top: 16, left: 16, bottom: 0, right: 16))
        stackView.addArrangedSubview(titleContainer)

        stackView.addArrangedSubview(thumbnailImageView)
        
        let commentsAndScoreView = UIView()
        
        let bottomStackView = UIStackView()
        bottomStackView.distribution = .fillEqually
        bottomStackView.spacing = 16
        bottomStackView.addArrangedSubview(scoreLabel)
        bottomStackView.addArrangedSubview(commentsLabel)
        commentsAndScoreView.addSubview(view: bottomStackView, edges: UIEdgeInsets(top: 0, left: 16, bottom: 16, right: 16))
        
        stackView.addArrangedSubview(commentsAndScoreView)

        titleLabel.numberOfLines = 0
        scoreLabel.numberOfLines = 0
        commentsLabel.numberOfLines = 0

        titleLabel.font = UIFont.boldSystemFont(ofSize: 22)
        scoreLabel.font = UIFont.systemFont(ofSize: 18)
        commentsLabel.font = UIFont.systemFont(ofSize: 18)
        
        commentsLabel.textAlignment = .center
        scoreLabel.textAlignment = .center

        imageViewWidthConstraint = thumbnailImageView.widthAnchor.constraint(equalToConstant: 0)
        imageViewHeightConstraint = thumbnailImageView.heightAnchor.constraint(equalToConstant: 0)
        imageViewWidthConstraint?.isActive = true
        imageViewHeightConstraint?.isActive = true
    }
}
