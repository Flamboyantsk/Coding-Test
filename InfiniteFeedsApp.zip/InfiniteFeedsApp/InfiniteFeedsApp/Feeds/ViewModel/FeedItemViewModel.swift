//
//  FeedItemViewModel.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

struct FeedItemViewModel {
    let feedItem: FeedItem
    
    init(feedItem: FeedItem) {
        self.feedItem = feedItem
    }
    
    var imageUrl: String? {
        feedItem.data.imageUrl
    }

    var title: String? {
        feedItem.data.title
    }
    
    var commentNumber: String {
        "Comments: \(feedItem.data.commentNumber ?? 0)"
    }
    
    var score: String {
        "Score: \(feedItem.data.score ?? 0)"
    }
    
    private var imageWidth: Int? {
        feedItem.data.imageWidth
    }
    
    private var imageHeight: Int? {
        feedItem.data.imageHeight
    }
    
    func imageSizeFor(viewWidth: CGFloat) -> CGSize {
        guard let imageWidth = self.imageWidth, let imageHeight = self.imageHeight else {
            return CGSize(width: viewWidth, height: viewWidth/2)
        }
        
        let diff = viewWidth / CGFloat(imageWidth)
        
        return CGSize(width: CGFloat(imageWidth) * diff, height: CGFloat(imageHeight) * diff)
    }
}
