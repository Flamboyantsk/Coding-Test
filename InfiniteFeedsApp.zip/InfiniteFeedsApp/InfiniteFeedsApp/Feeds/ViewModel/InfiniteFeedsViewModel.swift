//
//  InfiniteFeedsViewModel.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import Foundation

class InfiniteFeedsViewModel {
    private let apiClient: DataProvider
    private var items: [FeedItemViewModel] = []
    private var currentFeedResponse: FeedAPIResponse?
    private var isFeedsLoading = false {
        didSet {
            self.showLoadingIndicator?(self.isFeedsLoading)
        }
    }

    init(apiClient: DataProvider = FeedsAPIClient()) {
        self.apiClient = apiClient
    }
    
    var reloadTableViewClosure: (()->())?
    var showLoadingIndicator: ((Bool)->())?
    var showAlertClosure: (()->())?
    
    var alertMessage: String? {
        didSet {
            self.showAlertClosure?()
        }
    }
    
    var numberOfItems: Int {
        self.items.count
    }
    
    func feedItemAt(index: Int) -> FeedItemViewModel? {
        guard index < self.items.count else { return nil }
        return self.items[index]
    }
    
    func loadNextFeedIfAvailable() {
        guard !self.isFeedsLoading else { return }
        
        self.isFeedsLoading = true
        self.apiClient.fetchRemote(FeedAPIResponse.self, param: self.nextPageParameter) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .failure(let error):
                self.alertMessage = error.reason
            case .success(let response):
                self.currentFeedResponse = response
                let items = response.data.feedItems.map { FeedItemViewModel(feedItem: $0) }
                self.items.append(contentsOf: items)
                self.reloadTableViewClosure?()
            }
            self.isFeedsLoading = false
        }
    }
    
    private var nextPageParameter: [String: String]? {
        guard let after = self.currentFeedResponse?.data.after else { return nil }
        return ["after": after]
    }
}
