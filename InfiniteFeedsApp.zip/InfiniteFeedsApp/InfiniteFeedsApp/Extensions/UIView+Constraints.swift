//
//  UIView+Constraints.swift
//  InfiniteFeedsApp
//
//  Created by Farhan on 11/08/21.
//

import UIKit

extension UIView {

    func addSubview(view: UIView, edges: UIEdgeInsets = .zero) {
        addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.leftAnchor.constraint(equalTo: leftAnchor, constant: edges.left),
            rightAnchor.constraint(equalTo: view.rightAnchor, constant: edges.right),
            view.topAnchor.constraint(equalTo: topAnchor, constant: edges.top),
            bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: edges.bottom)
        ])
    }
    
    func addSubviewWithSafeArea(view: UIView, edges: UIEdgeInsets = .zero) {
        addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.leftAnchor.constraint(equalTo: leftAnchor, constant: edges.left),
            rightAnchor.constraint(equalTo: view.rightAnchor, constant: edges.right),
            view.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: edges.top),
            safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: edges.bottom)
        ])
    }
}
